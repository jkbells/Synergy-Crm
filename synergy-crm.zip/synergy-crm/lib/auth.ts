import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { db } from "./db";
// Resolves the signed-in user to a workspace. Every API route calls this first.
export async function requireWorkspace() {
  const jar = await cookies();
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { getAll: () => jar.getAll(), setAll: () => {} } });
  const { data } = await sb.auth.getUser();
  if (!data.user) throw new Response("Unauthorized", { status: 401 });
  let m = await db.member.findUnique({ where: { authUserId: data.user.id } });
  if (!m) {
    const w = await db.workspace.create({ data: { name: "My Workspace" } });
    m = await db.member.create({ data: { workspaceId: w.id, authUserId: data.user.id, email: data.user.email ?? "", role: "OWNER" } });
  }
  return m.workspaceId;
}
