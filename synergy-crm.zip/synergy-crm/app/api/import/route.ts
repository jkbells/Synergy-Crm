import { z } from "zod";
import { db } from "@/lib/db";
import { requireWorkspace } from "@/lib/auth";
// Import parsed rows as contacts: creates companies, dedupes by email. mapping = crmField -> csvColumn
const schema = z.object({ rows: z.array(z.record(z.any())).max(20000), mapping: z.record(z.string()) });
export async function POST(req: Request) {
  try {
    const w = await requireWorkspace(); const { rows, mapping: m } = schema.parse(await req.json()); let created = 0, skipped = 0;
    const s = (r: Record<string, unknown>, k: string) => (m[k] ? String(r[m[k]] ?? "").trim() || undefined : undefined);
    for (const r of rows) {
      const email = s(r, "email")?.toLowerCase();
      if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { skipped++; continue; }
      const cn = s(r, "company");
      const c = cn ? await db.company.upsert({ where: { workspaceId_name: { workspaceId: w, name: cn } }, update: {}, create: { workspaceId: w, name: cn } }) : null;
      await db.contact.upsert({
        where: { workspaceId_email: { workspaceId: w, email } }, update: {},
        create: { workspaceId: w, email, companyId: c?.id, firstName: s(r, "firstName"), lastName: s(r, "lastName"), title: s(r, "title"), country: s(r, "country") },
      });
      created++;
    }
    return Response.json({ created, skipped });
  } catch (e) { return e instanceof Response ? e : new Response("Request failed", { status: 400 }); }
}
