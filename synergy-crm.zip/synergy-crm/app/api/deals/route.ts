import { z } from "zod";
import { db } from "@/lib/db";
import { requireWorkspace } from "@/lib/auth";
const fail = (e: unknown) => (e instanceof Response ? e : new Response("Request failed", { status: 400 }));
export async function GET() {
  try {
    const w = await requireWorkspace();
    return Response.json(await db.pipeline.findMany({ where: { workspaceId: w }, include: { stages: { orderBy: { order: "asc" }, include: { deals: true } } } }));
  } catch (e) { return fail(e); }
}
const mv = z.object({ id: z.string().uuid(), stageId: z.string().uuid() });
export async function PATCH(req: Request) { // drag a deal between pipeline columns
  try {
    const w = await requireWorkspace(); const { id, stageId } = mv.parse(await req.json());
    const st = await db.stage.findFirst({ where: { id: stageId, pipeline: { workspaceId: w } } });
    if (!st) return new Response("Not found", { status: 404 });
    const r = await db.deal.updateMany({ where: { id, workspaceId: w }, data: { stageId } });
    return r.count ? Response.json({ ok: true }) : new Response("Not found", { status: 404 });
  } catch (e) { return fail(e); }
}
