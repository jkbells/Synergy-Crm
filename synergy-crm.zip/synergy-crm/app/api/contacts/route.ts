import { z } from "zod";
import { db } from "@/lib/db";
import { requireWorkspace } from "@/lib/auth";
const body = z.object({
  firstName: z.string().max(100).optional(), lastName: z.string().max(100).optional(), email: z.string().email().optional(),
  title: z.string().optional(), country: z.string().optional(), companyName: z.string().optional(),
  lifecycle: z.enum(["SUBSCRIBER", "LEAD", "MQL", "SQL", "OPPORTUNITY", "CUSTOMER", "OTHER"]).optional(),
});
const fail = (e: unknown) => (e instanceof Response ? e : new Response("Request failed", { status: 400 }));
export async function GET(req: Request) {
  try {
    const w = await requireWorkspace(); const u = new URL(req.url);
    const q = u.searchParams.get("q") ?? ""; const take = Math.min(100, +(u.searchParams.get("take") ?? 50)); const cursor = u.searchParams.get("cursor");
    const rows = await db.contact.findMany({
      where: { workspaceId: w, ...(q && { OR: [{ email: { contains: q, mode: "insensitive" } }, { lastName: { contains: q, mode: "insensitive" } }] }) },
      include: { company: true }, take: take + 1, ...(cursor && { cursor: { id: cursor }, skip: 1 }), orderBy: { createdAt: "desc" },
    });
    return Response.json({ items: rows.slice(0, take), next: rows.length > take ? rows[take - 1].id : null });
  } catch (e) { return fail(e); }
}
export async function POST(req: Request) {
  try {
    const w = await requireWorkspace(); const { companyName, ...d } = body.parse(await req.json());
    const company = companyName ? await db.company.upsert({ where: { workspaceId_name: { workspaceId: w, name: companyName } }, update: {}, create: { workspaceId: w, name: companyName } }) : null;
    return Response.json(await db.contact.create({ data: { ...d, workspaceId: w, companyId: company?.id } }), { status: 201 });
  } catch (e) { return fail(e); }
}
